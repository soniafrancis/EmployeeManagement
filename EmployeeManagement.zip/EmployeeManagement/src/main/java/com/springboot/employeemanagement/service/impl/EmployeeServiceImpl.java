package com.springboot.employeemanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.springboot.employeemanagement.model.Employee;
import com.springboot.employeemanagement.repo.EmployeeRepo;
import com.springboot.employeemanagement.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepo.save(employee);
				
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepo.findAll();
	}
	



	@Override
	public Employee getEmployeeById(Long id) {
		Optional <Employee> employee = employeeRepo.findById(id);
		return employeeRepo.findById(id).orElseThrow();
		
		
		}
	@Override
	public Employee updateEmployee(Employee employee, Long empId) {
		return employeeRepo.save(employee) ;
	}

	@Override
	public void deleteEmployee(Long empId) {
		employeeRepo.deleteById(empId);
		
	}


}
