package com.springboot.employeemanagement.service;

import java.util.List;

import com.springboot.employeemanagement.model.Employee;

public interface EmployeeService {
	
	Employee saveEmployee(Employee employee);
	
	//getAll employees
	List<Employee> getAllEmployees();
	
	//getById
	Employee getEmployeeById( Long empId);
	
	//Update employee
	Employee updateEmployee(Employee employee, Long empId);

	
	//Delete Employee
	void deleteEmployee(Long empId);

	

}
