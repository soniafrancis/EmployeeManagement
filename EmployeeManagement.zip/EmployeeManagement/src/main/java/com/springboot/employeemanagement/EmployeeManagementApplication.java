package com.springboot.employeemanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.springboot.employeemanagement.model.Employee;
import com.springboot.employeemanagement.service.EmployeeService;

@SpringBootApplication
public class EmployeeManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementApplication.class, args);
	}
@Autowired
private EmployeeService employeeService;
	@Bean
	public CommandLineRunner initDB()
	{
		return (args) -> {
			this.employeeService.saveEmployee(new Employee("john","john@gmail.com","23","ernakulam","Male"));
			this.employeeService.saveEmployee(new Employee("jeo","joe@gmail.com","24","Thrissur","Male"));
		};
}
}